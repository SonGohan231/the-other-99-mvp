import Papa from 'papaparse';
import { ContentItem, RarityTier } from '../types';
import { USE_V2_CONTENT } from '../config/features';
import { loadContentV2 } from './csvLoaderV2';
import { ContentItemV2 } from '../types/contentV2';

async function loadFile(path: string): Promise<ContentItem[]> {
  const response = await fetch(path);
  if (!response.ok) throw new Error(`Failed to load ${path}`);
  const text = await response.text();
  const result = Papa.parse<ContentItem>(text, {
    delimiter: ';',
    header: true,
    skipEmptyLines: true,
    transformHeader: (h) => h.trim().replace(/^﻿/, ''),
    transform: (v) => v.trim(),
  });
  return result.data;
}

function rarityFromWeight(weight: number): RarityTier {
  if (weight >= 2.2) return 'legendary';
  if (weight >= 1.6) return 'epic';
  if (weight >= 1.2) return 'rare';
  return 'standard';
}

function mapV2ModeToCardPath(mode: string): string {
  const m = (mode || '').toLowerCase();
  if (m.includes('contradiction')) return 'Hidden Contradiction';
  if (m.includes('shadow')) return 'Shadow Question';
  if (m.includes('relationship')) return 'Social Mirror';
  if (m.includes('pressure')) return 'Control Gate';
  if (m.includes('controversial')) return 'Moral Dilemma';
  if (m.includes('consistency')) return 'Pattern Break';
  if (m.includes('archetype')) return 'Threshold Card';
  return 'Pattern Break';
}

function mapV2ToContentItem(item: ContentItemV2): ContentItem {
  const answerLabelsPl = item.answers.map((a) => a.labelPl || a.shortLabelPl).filter(Boolean);
  const answerLabelsEn = item.answers.map((a) => a.labelEn || a.shortLabelEn).filter(Boolean);

  const axisByAnswer: Record<string, Record<string, number>> = {};
  const revealByAnswer: Record<string, { pl: string; en: string }> = {};
  const answerIds: string[] = [];

  for (const answer of item.answers) {
    answerIds.push(answer.answerId);
    const labels = [answer.labelPl, answer.labelEn, answer.shortLabelPl, answer.shortLabelEn]
      .map((v) => (v ?? '').trim())
      .filter(Boolean);
    for (const label of labels) {
      axisByAnswer[label] = answer.axisDeltas;
      revealByAnswer[label] = {
        pl: answer.answerRevealShortPl || answer.patternRevealPl || '',
        en: answer.answerRevealShortEn || answer.patternRevealEn || '',
      };
    }
  }

  const rarity = rarityFromWeight(item.rarityWeight);
  const cardPath = mapV2ModeToCardPath(item.mode);

  return {
    id: item.questionId,
    version: 'v2',
    content_type: 'question',
    rarity_tier: rarity,
    rarity_score: String(item.rarityWeight || 1),
    category: item.categoryPl || item.categoryEn || 'v2',
    darkness_level: String(item.controversyLevel ?? 0),
    intimacy_level: String(item.sensitivityLevel ?? 0),
    psychological_intensity: String(Math.max(item.sensitivityLevel ?? 0, item.controversyLevel ?? 0)),
    prompt_pl: item.questionPl,
    prompt_en: item.questionEn,
    answer_type: item.answerType || 'forced_choice',
    answer_options_pl: answerLabelsPl.join('|'),
    answer_options_en: answerLabelsEn.join('|'),
    axis_target: item.primaryAxis,
    // V2 scoring is answer-level. Runtime resolves the selected answer through answer_axis_deltas_json.
    axis_delta_json: '{}',
    hidden_signal: '',
    reward_after_answer_pl: '',
    verification_type: '',
    moderation_level: '',
    paywall_weight: item.tier === 'premium' ? '1' : '0',
    notes: '',
    reward_type: 'insight',
    reward_intensity: String(item.rarityWeight || 1),
    community_reveal_type: 'estimated',
    profile_reveal_type: 'standard',
    unlock_type: '',
    next_hook_pl: '',
    next_hook_en: '',
    card_path: cardPath,
    theme_category: item.categoryEn || item.categoryPl || 'v2',
    access_tier: item.tier === 'premium' ? 'premium' : 'free',
    community_stat_seed_json: '{}',
    reward_sequence_json: '{}',
    sample_reward_screen_pl: '',
    canon_version: 'TO99_ARCHETYPE_CANON_1.0',
    safety_label: (item.safetyLabel as ContentItem['safety_label']) ?? 'safe',
    statistic_source_label: (item.statisticSourceLabel as ContentItem['statistic_source_label']) ?? 'estimated',
    allowed_actions: '',
    reveal_template_id: item.revealTemplateIds[0],
    sensitivity_level: String(item.sensitivityLevel ?? 0),
    controversy_level: String(item.controversyLevel ?? 0),
    content_contract_status: item.productionStatus === 'approved' ? 'approved' : 'reviewed',
    content_source: 'v2',
    content_version: '2.0.0',
    source_file: 'public/v2/questions_all_2650.csv+answers_all_5300.csv',
    question_id: item.questionId,
    answer_ids_json: JSON.stringify(answerIds),
    answer_axis_deltas_json: JSON.stringify(axisByAnswer),
    answer_reveal_shorts_json: JSON.stringify(revealByAnswer),
    source_mode: item.mode,
    source_tier: item.tier,
  };
}

async function loadLegacyContent(): Promise<ContentItem[]> {
  // Load primary content
  const primary = (await loadFile('/content.csv')).map((i) => ({
    ...i,
    content_source: 'legacy' as const,
    content_version: i.version || 'legacy',
    source_file: 'public/content.csv',
  }));

  // Try loading v2 legacy-format English-first CSV
  let v2: ContentItem[] = [];
  try {
    v2 = (await loadFile('/content_en_v2.csv')).map((i) => ({
      ...i,
      content_source: 'legacy' as const,
      content_version: i.version || 'legacy_en_v2',
      source_file: 'public/content_en_v2.csv',
    }));
  } catch { /* ok */ }

  // Try loading premium content
  let premium: ContentItem[] = [];
  try {
    const raw = await loadFile('/content_premium_en_v1.csv');
    premium = raw.map(item => ({
      ...item,
      access_tier: 'premium' as const,
      content_source: 'legacy' as const,
      content_version: item.version || 'legacy_premium',
      source_file: 'public/content_premium_en_v1.csv',
    }));
  } catch { /* ok */ }

  return [...primary, ...v2, ...premium];
}

export async function loadContent(): Promise<ContentItem[]> {
  let all: ContentItem[];

  if (USE_V2_CONTENT) {
    const v2Items = await loadContentV2();
    all = v2Items.map(mapV2ToContentItem);
  } else {
    all = await loadLegacyContent();
  }

  // Deduplicate by id
  const seen = new Set<string>();
  return all.filter(item => {
    if (!item.id || seen.has(item.id)) return false;
    if (!item.prompt_pl && !item.prompt_en) return false;
    seen.add(item.id);
    return true;
  });
}
