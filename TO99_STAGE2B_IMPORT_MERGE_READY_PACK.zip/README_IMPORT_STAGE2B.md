# TO99 Stage 2B Import Notes

This package merges Stage 2A S2A-01 through S2A-24 into one import-ready V3 content set.

## Copy into repo

```bash
mkdir -p public/v3 docs
cp TO99_questions_master.csv public/v3/TO99_questions_master.csv
cp TO99_answers_long.csv public/v3/TO99_answers_long.csv
cp TO99_answer_reveals.csv public/v3/TO99_answer_reveals.csv
cp TO99_database_schema_stage2B.csv public/v3/TO99_database_schema_stage2B.csv
cp TO99_STAGE2B_IMPORT_MERGE_VALIDATION_REPORT.md docs/TO99_STAGE2B_IMPORT_MERGE_VALIDATION_REPORT.md
cp TO99_STAGE2B_VALIDATION_SUMMARY.json docs/TO99_STAGE2B_VALIDATION_SUMMARY.json
```

## Loader rule
The app must join answers by `question_id`. Do not use generic answer families.

## Expected runtime diagnostics
- questions_loaded = 2400
- answers_loaded = 9600
- answer_reveals_loaded = 9600
- fallback_answers_used = 0
- content_source = stage2B_v3
