# TO99 Stage 2B Import/Merge Validation Report

Generated after merging Stage 2A batches S2A-01 through S2A-24.

## Counts

- Questions: 2400
- Answers: 9600
- Reveals: 9600
- Duplicate question_id: 0
- Duplicate answer_id: 0
- Duplicate reveal_id: 0
- Questions with !=4 answers: 0
- Questions missing exact A/B/C/D: 0
- Questions where projected_distribution_percent sum != 100: 0
- Questions missing in answers: 0
- Extra question ids in answers: 0
- Questions missing in reveals: 0
- Extra question ids in reveals: 0
- Reveals missing answer_id match: 0
- Answers missing reveal row: 0
- [variant]/[wariant] visible labels: 0
- Empty questions.question_pl: 0
- Empty questions.question_en: 0
- Empty questions.primary_axis: 0
- Empty answers.answer_pl: 0
- Empty answers.answer_en: 0
- Empty answers.question_id: 0
- Empty answers.option_key: 0
- Empty reveals.short_reveal_pl: 0
- Empty reveals.short_reveal_en: 0
- Empty reveals.comparison_insight_pl: 0
- Empty reveals.comparison_insight_en: 0
- Empty reveals.pattern_signal_pl: 0
- Empty reveals.pattern_signal_en: 0
- Duplicate normalized EN question text rows: 0
- Questions with duplicated normalized answer_en inside one question: 0

## Primary axis distribution

- AX01: 200
- AX02: 200
- AX03: 360
- AX04: 200
- AX05: 320
- AX06: 200
- AX07: 200
- AX08: 320
- AX09: 200
- AX10: 200

## Batch coverage

- S2A-01: 100 questions
- S2A-02: 100 questions
- S2A-03: 100 questions
- S2A-04: 100 questions
- S2A-05: 100 questions
- S2A-06: 100 questions
- S2A-07: 100 questions
- S2A-08: 100 questions
- S2A-09: 100 questions
- S2A-10: 100 questions
- S2A-11: 100 questions
- S2A-12: 100 questions
- S2A-13: 100 questions
- S2A-14: 100 questions
- S2A-15: 100 questions
- S2A-16: 100 questions
- S2A-17: 100 questions
- S2A-18: 100 questions
- S2A-19: 100 questions
- S2A-20: 100 questions
- S2A-21: 100 questions
- S2A-22: 100 questions
- S2A-23: 100 questions
- S2A-24: 100 questions

## Result

STATUS: PASS

## Required manual QA sample

- TO99Q0001: A new place online feels fascinating but slightly unsafe. What do you check first?
- TO99Q0005: A group clearly knows a secret you were not told. What is your first internal reaction?
- TO99Q0017: An old family wound returns during an ordinary meal. What do you protect first?
- TO99Q0051: On a trip, a side street looks more alive than the plan. What do you do?
- TO99Q0099: A spark and a blueprint argue inside you. Which one leads?
- TO99Q0100: In a team, you see the idea before others see the steps. What do you do?
- TO99Q0101: A shortcut appears in a system you barely understand. What do you check before using it?
- TO99Q0200: You are ready to launch, but one small part still feels unfinished. What decides?
- TO99Q0401: In a team that is celebrating a success: A close group expects loyalty, but your own version of the truth does not fit t
- TO99Q0600: When someone is waiting for a clear answer: You can risk something now and discover something, or wait and maybe never r
- TO99Q0777: You find a note from your future self: “what you postpone also chooses for you” when the issue is already partly public.
- TO99Q0999: The majority chooses the option that looks good from outside: the decision looks noble. What do you check underneath?
- TO99Q1200: When the decision technically works, but you do not know whether it has meaning, what do you check first?
- TO99Q1600: When the day asks for adjustment and ego asks for results, what do you give a voice to - around: moment when recovery fe
- TO99Q2000: What do you do when hope is so private you protect it from your own cynicism, and the hardest part is naming tenderness 
- TO99Q2400: What do you do when the final layer does not give an answer, only a better question, but you do not want to confuse the 