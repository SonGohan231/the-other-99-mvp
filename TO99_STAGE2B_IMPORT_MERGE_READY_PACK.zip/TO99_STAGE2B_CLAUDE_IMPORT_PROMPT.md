# THE OTHER 99 - STAGE 2B IMPORT/MERGE + LOADER VERIFICATION PROMPT

You are continuing the frozen plan for The Other 99.

ACTIVE STAGE: Stage 2B - Import/Merge Content and Loader Validation.
DO NOT move to Stage 3.
DO NOT redesign UI.
DO NOT generate new questions.
DO NOT replace the scoring model.

SOURCE PACKAGE:
Use the Stage 2B package files from this ZIP. Required content files:
- TO99_questions_master.csv: 2400 questions
- TO99_answers_long.csv: 9600 answers
- TO99_answer_reveals.csv: 9600 reveal/social/pattern rows
- TO99_database_schema_stage2B.csv
- TO99_STAGE2B_VALIDATION_SUMMARY.json
- TO99_STAGE2B_IMPORT_MERGE_VALIDATION_REPORT.md

GOAL:
Make the app load the new Stage 2B content so that every question_id has exactly four dedicated answers A/B/C/D and the app never falls back to generic/filler answers.

REQUIRED IMPLEMENTATION STEPS:
1. Create a new branch from main, for example:
   git checkout main
   git pull origin main
   git checkout -b stage2b-content-import-loader-validation

2. Copy files into repo:
   public/v3/TO99_questions_master.csv
   public/v3/TO99_answers_long.csv
   public/v3/TO99_answer_reveals.csv
   public/v3/TO99_database_schema_stage2B.csv
   docs/TO99_STAGE2B_IMPORT_MERGE_VALIDATION_REPORT.md
   docs/TO99_STAGE2B_VALIDATION_SUMMARY.json

3. Inspect the current loader before editing. Identify exactly which loader is used by App.tsx.
   Likely files to inspect:
   - src/App.tsx
   - src/utils/csvLoader.ts
   - src/utils/csvLoaderV2.ts
   - src/types.ts

4. Implement or repair the V3 loader contract:
   - load TO99_questions_master.csv
   - load TO99_answers_long.csv
   - join answers by question_id
   - require exactly four answers A/B/C/D per question
   - preserve answer-specific axis deltas and hidden deltas
   - preserve short_reveal, comparison_insight, pattern_signal, micro_reward, projected_distribution_percent
   - strip any visible [variant]/[wariant] labels defensively
   - fail loudly in diagnostics if a question has missing answers

5. Disable generic answer fallback for production V3 content.
   A fallback may remain only as explicit debug/test fallback and must be labeled as fallback in diagnostics.

6. Verify the app behavior manually:
   - Question 1 shows 4 answers from TO99Q0001
   - Question 5 shows 4 answers from TO99Q0005
   - Question 17 shows 4 answers from TO99Q0017
   - Question 101 shows 4 answers from TO99Q0101 if seeded/debug-routed
   - Question 2400 exists in content diagnostics
   - no question text contains [variant]
   - no repeated generic answer family appears across unrelated questions

7. Update export/debug diagnostics:
   Required export fields must include:
   - content_source: stage2B_v3
   - questions_loaded: 2400
   - answers_loaded: 9600
   - answer_reveals_loaded: 9600
   - questions_with_missing_answers: 0
   - fallback_answers_used: 0 in normal app path
   - canonical_vector
   - profile_vector
   - content_diagnostics

8. Run validation commands:
   npm run validate:content-quality || npm run validate:content || node scripts/validate-content-v3.mjs
   npx tsc --noEmit
   npm run build

9. Commit and push:
   git add public/v3 docs src scripts package.json package-lock.json
   git commit -m "stage2b: import full V3 content and validate loader"
   git push -u origin stage2b-content-import-loader-validation

ACCEPTANCE CRITERIA:
- 2400 questions loaded.
- 9600 answers loaded.
- Every loaded question has exactly 4 dedicated answers.
- No visible [variant]/[wariant].
- No fallback/generic answers in normal user flow.
- Social comparison and reveal text come from answer row / reveal row.
- TypeScript clean.
- Build clean.
- Debug/export proves stage2B_v3 content source.

FINAL RESPONSE REQUIRED:
Return:
1. branch name
2. commit hash
3. files changed
4. exact loader path used by App.tsx
5. counts from runtime diagnostics
6. sample question IDs tested with answer IDs shown
7. validation result
8. remaining risks
